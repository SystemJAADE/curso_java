package pe.edu.galaxy.training.java.jd0.estswitch;

public class AppSwitch {

	public static void main(String[] args) {
		
		/* Entero, char, String*/
		
		int key=2;
		
		switch (key) {
			case 1:{
				System.out.println("Enero");
				break;
			}
			case 2:{
				System.out.println("Febrero");
				break;
			}	
			default:
				System.out.println("No v�lido");
				break;
			}
	}

}
