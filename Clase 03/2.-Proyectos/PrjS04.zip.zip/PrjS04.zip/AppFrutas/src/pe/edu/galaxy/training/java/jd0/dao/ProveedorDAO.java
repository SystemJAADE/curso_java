package pe.edu.galaxy.training.java.jd0.dao;

import pe.edu.galaxy.training.java.jd0.beans.Proveedor;

public interface ProveedorDAO extends GenericoDAO<Proveedor>{

	
}
