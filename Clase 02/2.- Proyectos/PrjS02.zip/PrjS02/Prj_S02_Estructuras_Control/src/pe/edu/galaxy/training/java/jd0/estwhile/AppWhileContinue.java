package pe.edu.galaxy.training.java.jd0.estwhile;

public class AppWhileContinue {

	public static void main(String[] args) {

		int i = 0;
		while (i < 10) {
			i++;
			if (i==5) {
				continue;
			}
			System.out.println(i);
		}

		System.out.println();

	}
}
