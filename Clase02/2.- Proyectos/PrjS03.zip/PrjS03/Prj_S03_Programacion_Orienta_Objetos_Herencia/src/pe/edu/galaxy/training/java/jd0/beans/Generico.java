package pe.edu.galaxy.training.java.jd0.beans;

public class Generico {

	protected Integer codigo;
	protected String estado;

	public Generico() {
		this.codigo = 0;
		this.estado = "1";
	}

	public Generico(Integer codigo) {
		super();
		this.codigo = codigo;
		this.estado = "1";
	}

	public Integer getCodigo() {
		return codigo;
	}

	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}
}
