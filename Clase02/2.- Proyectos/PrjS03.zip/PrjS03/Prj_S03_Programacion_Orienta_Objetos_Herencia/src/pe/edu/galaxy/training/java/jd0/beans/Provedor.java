package pe.edu.galaxy.training.java.jd0.beans;

public class Provedor extends Generico{

	// Atributos
	private String 	razonSocial;
	private String 	ruc;

	// M�todos

	// Constructores
	public Provedor() {

	}

	public Provedor(Integer codigo, String razonSocial, String ruc) {
		super(codigo);
		this.razonSocial = razonSocial;
		this.ruc = ruc;
	}


	@Override
	public String toString() {
		return "Provedor [razonSocial=" + razonSocial + ", ruc=" + ruc + "]";
	}

	public String getRazonSocial() {
		return razonSocial;
	}

	public void setRazonSocial(String razonSocial) {
		this.razonSocial = razonSocial;
	}

	public String getRuc() {
		return ruc;
	}

	public void setRuc(String ruc) {
		this.ruc = ruc;
	}

	
}
