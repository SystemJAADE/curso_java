package pe.edu.galaxy.training.java.jd0.caso.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class BD {
	
	private static String url 		= "jdbc:oracle:thin:@localhost:1521:xe";
	private static String driver 	= "oracle.jdbc.OracleDriver";
	private static String usuario 	= "JD026";
	private static String clave 	= "123456";
	
	public static Connection getConnection() throws SQLException{
		if (!loadDriver()) {
			return null;
		}
		try {
			Connection cn = DriverManager.getConnection(url, usuario, clave);
			return cn;
		} catch (Exception e) {
			e.printStackTrace();
			throw new SQLException(e);
		}
	}
	
	public static Connection getConnection(String usuario,String clave) throws SQLException{
		BD.usuario=usuario;
		BD.clave=clave;
		return getConnection();
	}
	
	public static Connection getConnection(String usuario,String clave,String url) throws SQLException{
		BD.usuario=usuario;
		BD.clave=clave;
		BD.url=url;
		return getConnection();
	}
	
	private static boolean loadDriver(String driver)throws SQLException {
		BD.driver=driver;
		return loadDriver();
	}
	
	private static boolean loadDriver()throws SQLException {
		try {
			Class.forName(driver);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			throw new SQLException(e);
		}
		
	}
}
