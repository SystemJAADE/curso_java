package pe.edu.galaxy.training.java.jd0;

import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.Scanner;

public class AppArchivoEscritura {

	public static void main(String[] args) {

		try {

			FileWriter archivo = null;
			PrintWriter pw = null;
			// Z://192.168.1.45/archivos/2021/10
			String file = "D://tmp//archivo-java-octubre-2021.txt";
			archivo = new FileWriter(file, true);

			pw = new PrintWriter(archivo, true);
			Scanner scanner = new Scanner(System.in);

			System.out.println("Ingrese un registro:");

			String registro = scanner.nextLine();

			pw.println(registro);

			if (archivo != null) {
				archivo.close();
			}
			if (scanner != null) {
				scanner.close();
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
