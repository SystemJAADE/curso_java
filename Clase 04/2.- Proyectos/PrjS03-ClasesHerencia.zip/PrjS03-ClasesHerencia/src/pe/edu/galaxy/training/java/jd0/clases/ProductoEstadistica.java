package pe.edu.galaxy.training.java.jd0.clases;

import java.util.Date;

public class ProductoEstadistica {

		private Date fechaInicioVenta;
		private Date fechaUltimaVenta;
		
		///....
		
}
