package pe.edu.galaxy.training.java.pf.interfazfunctional;

import pe.edu.galaxy.training.java.pf.beans.Producto;

@FunctionalInterface
public interface Valorizar {

	double valorizar(Producto p);
	
}
