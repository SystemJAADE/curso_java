package pe.edu.galaxy.training.java.jd0.estif;

public class AppIfElseIf {

	public static void main(String[] args) {

		float nota = 6.6f;

		if (nota >= 10.5) {
			System.out.println("Aprobado");
		} else if (nota > 5.0) {
			System.out.println("Desaprobado subsanable");
		} else {
			System.out.println("Desaprobado p�simo");
		}

	}

}
