package pe.edu.galaxy.training.java.jd0.matematicos.poo;

public class AppPOO {

	public static void main(String[] args) {
		
		int b=5;
		
		b=b+1;
		
		System.out.println(b);
		
		b++;
		
		System.out.println(b);
		
		System.out.println(++b);
		
		System.out.println(--b);
		
		System.out.println(b--);
		
		System.out.println(b);
		
		b=b+5;
		
		b=20;
		
		System.out.println();
		
		System.out.println(b+=5);
		System.out.println(b-=5);
		System.out.println(b*=5);
		System.out.println(b/=5);
		System.out.println(b%=6);
		
	}

}
