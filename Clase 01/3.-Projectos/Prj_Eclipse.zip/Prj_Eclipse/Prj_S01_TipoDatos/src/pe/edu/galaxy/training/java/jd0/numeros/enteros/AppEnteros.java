package pe.edu.galaxy.training.java.jd0.numeros.enteros;

import java.lang.Byte;

public class AppEnteros {

	public static void main(String[] args) {
		
		// Menor -> Meyor
		
		byte b= 100;
		byte b1= -128;
		
		Byte b2=100;
		
		b2=b1; // Boxing <==>UnBoxing
		System.out.println(b2);
		System.out.println(Byte.MIN_VALUE +" / "+ Byte.MAX_VALUE);
		
		String s="20";
		
		System.out.println(Byte.valueOf(s)+b);
		System.out.println(Byte.parseByte(s)+b);
		
		
		System.out.println((char)64); // Cast converter
		System.out.println((byte)'@');
		System.out.println(String.valueOf(100)+"A");
		System.out.println(1+100+"1");
		
		short s0= 10_898;
		short s1= -32_000;
		
		Short s2=100;
		
		s2=s1; // Boxing <==>UnBoxing
		System.out.println(s2);
		System.out.println(Short.MIN_VALUE +" / "+ Short.MAX_VALUE);
		
		String str2="20000";
		
		System.out.println(Short.valueOf(str2)+b);
		System.out.println(Short.parseShort(str2)+b);
		
		int i0= 10_898;
		int i1= -32_000;
		
		Short s3=100;
		
		System.out.println(Integer.MIN_VALUE +" / "+ Integer.MAX_VALUE);
		
		String str3="20000";
		
		System.out.println(Integer.valueOf(str3)+b);
		
		long l0= 10_898;
		long l1= -32_000;
		
		Short s4=100;
		
		System.out.println(Long.MIN_VALUE +" / "+ Long.MAX_VALUE);
		
		String str4="200000000";
		
		System.out.println(Long.valueOf(str4)+b);
		
	}

}
