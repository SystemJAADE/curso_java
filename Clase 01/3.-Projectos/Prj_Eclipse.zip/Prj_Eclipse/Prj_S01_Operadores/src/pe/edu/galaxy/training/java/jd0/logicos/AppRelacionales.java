package pe.edu.galaxy.training.java.jd0.logicos;

public class AppRelacionales {

	public static void main(String[] args) {
		
		// >, >=, <,<=, ==, !=
		
		short nota= (short) 14.5;
		
		if (nota>10.5) {
			System.out.println("Aprobado");
		}
		
		nota= (short) 10.5;
		
		if (nota>=10.5) {
			System.out.println("Aprobado");
		}else {
			System.out.println("Desaprobado");
		}
		
		nota=5;
		
		if (nota<5) {
			System.out.println("P�simo");
		}
		
		if (nota<=5) {
			System.out.println("P�simo.");
		}
		nota=20;
		if (nota==20) {
			System.out.println("Excelente.");
		}
		
		if (nota!=10) {
			System.out.println("Diferente de 10");
		}
		
		
	}
}
