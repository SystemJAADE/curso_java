package pe.edu.galaxy.training.java.jd0.cadenas;

public class AppString {

	public static void main(String[] args) {
		
		
		String s="Java ";
		
		String s1=new String("Java ");
		String s2=new String("Java ");
		
		System.out.println(s);
		
		System.out.println(s.length());			// Longitud
		System.out.println(s.trim().length());	// Eliminar espacios en blanco
		
		System.out.println(s.toUpperCase());
		System.out.println(s.toLowerCase());
		
		System.out.println(s.concat(" B�sico"));
		
		if (s=="Java ") { // Mala pr�ctica
			System.out.println("Son iguales");
		}
		
		if (s.equals("Java ")) { // Buena pr�ctica
			System.out.println("Son iguales");
		}
		
		if (s==s1) { // Mala pr�ctica
			System.out.println("Son iguales");
		}else {
			System.out.println("No son iguales");
		}
		
		if (s.compareTo("java ")==0) { // Buena pr�ctica
			System.out.println("Son iguales");
		}
		
		if (s.compareToIgnoreCase("java ")==0) { // Buena pr�ctica
			System.out.println("Son iguales");
		}
		
		System.out.println(s.indexOf("w"));
		System.out.println(s.lastIndexOf("a"));
		
		System.out.println(s.charAt(0));

		System.out.println(s); // Inmutable
	}

}
