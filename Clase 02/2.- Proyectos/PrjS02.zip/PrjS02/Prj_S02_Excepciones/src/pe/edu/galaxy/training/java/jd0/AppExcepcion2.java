package pe.edu.galaxy.training.java.jd0;

public class AppExcepcion2 {

	public static void main(String[] args) {
		
		try {
			System.out.println(10/3);
		} catch (Exception e) {
			//e.printStackTrace();
			System.err.println(e.getMessage());
		}
	

	}

}
