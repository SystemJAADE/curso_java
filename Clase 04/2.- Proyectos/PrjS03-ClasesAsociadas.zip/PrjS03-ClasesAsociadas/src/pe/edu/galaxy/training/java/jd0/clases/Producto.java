package pe.edu.galaxy.training.java.jd0.clases;

public class Producto {

	// Atributos

	private Integer codigo;
	private String nombre;
	private Double precio;
	private Integer stock;
	private Boolean activo;
	
	//private Integer idCategoria; // Error
	
	private Categoria categoria; //UDT
	

	// Metodos

	// Constructores
	public Producto() {// Constructro vaci�
		super();
		this.activo=true;
	}

	public Producto(Integer codigo, String nombre, Double precio, Integer stock) {
		super();
		this.codigo = codigo;
		this.nombre = nombre;
		this.precio = precio;
		this.stock = stock;
		this.activo=true;
	}
	
	
	public Producto(Integer codigo, String nombre, Double precio, Integer stock, Boolean activo) {
		super();
		this.codigo = codigo;
		this.nombre = nombre;
		this.precio = precio;
		this.stock = stock;
		this.activo = activo;
	}

	// Getters/Setters

	// Set
	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}

	// Get
	public Integer getCodigo() {
		return codigo;
	}

	public Double getPrecio() {
		return precio;
	}

	public void setPrecio(Double precio) {
		this.precio = precio;
	}

	public Integer getStock() {
		return stock;
	}

	public void setStock(Integer stock) {
		this.stock = stock;
	}

	public Boolean getActivo() {
		return activo;
	}

	public void setActivo(Boolean activo) {
		this.activo = activo;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	// Operacionales
	
	public Double getTotal() {
		if (stock>0) {
			return precio*stock;
		}
		return 0.0;
	}
	
	//toString()
	@Override
	public String toString() {
		return "Producto [codigo=" + codigo + ", nombre=" + nombre + ", precio=" + precio + ", stock=" + stock
				+ ", total="+getTotal() + ", " + categoria.toString() + ", activo=" + activo  +"]";
	}

	public Categoria getCategoria() {
		return categoria;
	}

	public void setCategoria(Categoria categoria) {
		this.categoria = categoria;
	}
	
}
