package pe.edu.java.galaxy.training;

public class MyHilo extends Thread{

    private StringBuffer sb;

    private String nombre;

    public MyHilo(String nombre, StringBuffer sb) {
        this.sb = sb;
        this.nombre=nombre;
    }

    @Override
   	public void run() {
       	  this.print();
   	}
    
	public /*synchronized*/ void print() {
        for (int i = 0; i < sb.length(); i++) {
            System.out.println(this.nombre+ " "+sb.charAt(i));
        }
    }

}
