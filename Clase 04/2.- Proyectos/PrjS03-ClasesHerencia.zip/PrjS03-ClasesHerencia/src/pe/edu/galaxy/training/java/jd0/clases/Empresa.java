package pe.edu.galaxy.training.java.jd0.clases;

public class Empresa extends Generico{

	private String razonSocial;
	private String nroRUC;
	
	public Empresa() {
		super();
	}
	public String getRazonSocial() {
		return razonSocial;
	}
	public void setRazonSocial(String razonSocial) {
		this.razonSocial = razonSocial;
	}
	public String getNroRUC() {
		return nroRUC;
	}
	public void setNroRUC(String nroRUC) {
		this.nroRUC = nroRUC;
	}
	
	
}
