package pe.edu.galaxy.training.java.jd0.clases;

public abstract class Generico {
	
	// Atributos
	
	private Integer codigo;
	private Boolean activo;
	
	public Generico() {
		this.activo=true;
	}
	
	public Generico(Integer codigo) {
		this.codigo=codigo;
		this.activo=true;
	}
	
	public Integer getCodigo() {
		return codigo;
	}

	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}
	
	public Boolean getActivo() {
		return activo;
	}

	public void setActivo(Boolean activo) {
		this.activo = activo;
	}

	@Override
	public String toString() {
		return "Generico [codigo=" + codigo + ", activo=" + activo + "]";
	}
	
	
}
