package com.novoa.training;

public class Demo01 {

    public static void main(String[] args) {

        System.out.println("Demo desde Intellij IDEA");
    }
}
