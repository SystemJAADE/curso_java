package pe.edu.galaxy.training.java.pf.service;

import java.util.ArrayList;
import java.util.List;
import pe.edu.galaxy.training.java.pf.beans.Producto;

public class ProductoServiceImpl implements ProductoService{
	
	static List<Producto> productos= new ArrayList<>();
	
	static {
		productos.add(new Producto(1, "P1", 150.00,1));
		productos.add(new Producto(2, "P2", 250.00,2));
		productos.add(new Producto(3, "P3", 350.00,5));
		productos.add(new Producto(4, "P4", 150.00,3));
		productos.add(new Producto(5, "P5", 120.00,3));
	}
	
	public ProductoServiceImpl(){
		//this.init();
	}
	/*
	private void init (){
		productos.add(new Producto(1, "P1", 150.00,1));
		productos.add(new Producto(2, "P2", 250.00,2));
		productos.add(new Producto(3, "P3", 350.00,5));
		productos.add(new Producto(4, "P4", 150.00,3));
		productos.add(new Producto(5, "P5", 120.00,3));
	}*/
	
	@Override
	public List<Producto> getAll() {
		return this.productos;
	}

	@Override
	public Producto findById(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

}
