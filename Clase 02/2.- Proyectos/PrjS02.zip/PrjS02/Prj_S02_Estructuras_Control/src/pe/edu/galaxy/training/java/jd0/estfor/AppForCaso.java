package pe.edu.galaxy.training.java.jd0.estfor;

public class AppForCaso {
	
	public static void main(String[] args) {

		String dni = "91061698";

		if (validar(dni)) {
			System.out.println(dni + " v�lido");
		}else {
			System.out.println(dni + " inv�lido");
		}
		
	}
	
	private static boolean validar(String dni) {
		for (int i = 0; i < dni.length(); i++) {
			System.out.println(dni.charAt(i));
			if (!Character.isDigit(dni.charAt(i))) {
				return false;
			}
		}
		return true;
	}
}
