package pe.edu.galaxy.training.java.jd0.list;

import java.util.HashSet;
import java.util.Set;

public class AppSet {

	public static void main(String[] args) {
		
		
		Set<String> frutas= new HashSet<>();
		
		frutas.add("Pera");
		frutas.add("Pi�a");
		frutas.add("Manana");
		frutas.add("Papaya");
		frutas.add("Pera");
		
		System.out.println();
		
		for (String fruta : frutas) { // For each
			System.out.println(fruta);
		}
		
		System.out.println();
		frutas.forEach(System.out::println);
		
		
	}

}
