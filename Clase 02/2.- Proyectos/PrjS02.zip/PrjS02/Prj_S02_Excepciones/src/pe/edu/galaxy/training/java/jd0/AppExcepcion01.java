package pe.edu.galaxy.training.java.jd0;

public class AppExcepcion01 {

	public static void main(String[] args) {
		
		System.out.println(10/0);

	}

}
