package pe.edu.galaxy.training.java.jd0;

public class AppDemo02 {

	public static void main(String[] args) {

	}

	class AppDemo02a1 {

	}

	class AppDemo02a2 {
		
		class AppDemo02a2a {

		}
	}
}

class AppDemo02a {

}