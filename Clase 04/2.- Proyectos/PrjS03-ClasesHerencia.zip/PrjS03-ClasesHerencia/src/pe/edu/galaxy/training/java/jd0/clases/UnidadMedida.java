package pe.edu.galaxy.training.java.jd0.clases;

public class UnidadMedida extends Generico{

	private String abreviatura;
	private String nombre;
	
	public UnidadMedida() {
		super();
	}

	public UnidadMedida(Integer codigo, String nombre) {
		super(codigo);
		this.nombre = nombre;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getAbreviatura() {
		return abreviatura;
	}

	public void setAbreviatura(String abreviatura) {
		this.abreviatura = abreviatura;
	}

	@Override
	public String toString() {
		return "UnidadMedida [abreviatura=" + abreviatura + ", nombre=" + nombre + "]";
	}
	
}
