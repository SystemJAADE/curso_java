package pe.edu.galaxy.training.java.jd0;

public interface DemoService {

}
