
package pe.edu.galaxy.training.java.albums.beans;

public class BaseBean {
    
    protected Long codigo;
    protected String estado;

    public BaseBean() {
    }

    public BaseBean(Long codigo) {
        this.codigo = codigo;
    }

    
    public Long getCodigo() {
        return codigo;
    }

    public void setCodigo(Long codigo) {
        this.codigo = codigo;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    @Override
    public String toString() {
        return "BaseBean{" + "codigo=" + codigo + ", estado=" + estado + '}';
    }
     
}
