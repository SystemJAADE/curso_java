package pe.edu.galaxy.training.java.jd0.estfor;

public class AppForContinue {

	public static void main(String[] args) {

		for (int i = 0; i < 10; i++) {
			if (i==5) {
				continue;
			}
			System.out.println(i);
		}
	}

}
