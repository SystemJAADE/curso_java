package pe.edu.galaxy.training.java.jd0.clases;

import java.util.List;

public class Producto extends Generico{

	// Atributos
	
	private String nombre;
	private Double precio;
	private Integer stock;
	
	private Categoria categoria;
	
	private List<Componente> componentes;

	private ProductoEstadistica estadistica;
	
	// Metodos

	// Constructores
	public Producto() {
		super();
	}

	public Producto(Integer codigo, String nombre, Double precio, Integer stock) {
		super(codigo);
		this.nombre = nombre;
		this.precio = precio;
		this.stock = stock;
	}
	
	public Producto(Integer codigo, String nombre, Double precio, Integer stock, Boolean activo) {
		super(codigo);
		this.nombre = nombre;
		this.precio = precio;
		this.stock = stock;
	}

	public Double getPrecio() {
		return precio;
	}

	public void setPrecio(Double precio) {
		this.precio = precio;
	}

	public Integer getStock() {
		return stock;
	}

	public void setStock(Integer stock) {
		this.stock = stock;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	// Operacionales
	
	public Double getTotal() {
		if (stock>0) {
			return precio*stock;
		}
		return 0.0;
	}


	public Categoria getCategoria() {
		return categoria;
	}

	public void setCategoria(Categoria categoria) {
		this.categoria = categoria;
	}

	@Override
	public String toString() {
		return "Producto [nombre=" + nombre + ", precio=" + precio + ", stock=" + stock + ", categoria=" + categoria
				+ ", toString()=" + super.toString() + "]";
	}
	
	
	public List<Componente> getComponentes() {
		return componentes;
	}

	public void setComponentes(List<Componente> componentes) {
		this.componentes = componentes;
	}


	public ProductoEstadistica getEstadistica() {
		return estadistica;
	}

	public void setEstadistica(ProductoEstadistica estadistica) {
		this.estadistica = estadistica;
	}

	public class Componente extends Generico{
		
		private String nombre;
		private String descripcion;
		 
		 
		public Componente() {
			super();
		}
		public String getNombre() {
			return nombre;
		}
		public void setNombre(String nombre) {
			this.nombre = nombre;
		}
		public String getDescripcion() {
			return descripcion;
		}
		public void setDescripcion(String descripcion) {
			this.descripcion = descripcion;
		}
		 
		 
	}
	
}
