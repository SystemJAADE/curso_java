package pe.edu.galaxy.training.java.pf.lamda;

import java.util.List;
import java.util.Optional;
import java.util.OptionalDouble;

import pe.edu.galaxy.training.java.pf.beans.Producto;
import pe.edu.galaxy.training.java.pf.service.ProductoService;
import pe.edu.galaxy.training.java.pf.service.ProductoServiceImpl;

public class App01 {

	public static void main(String[] args) {

		ProductoService ps = new ProductoServiceImpl();

		List<Producto> productos = ps.getAll();

		// System.out.println(productos);

		// Antiguo
		/*
		 * for (int i = 0; i < productos.size(); i++) {
		 * System.out.println(productos.get(i)); }
		 * 
		 * //
		 * 
		 * System.out.println("for each");
		 * 
		 * for (Producto producto : productos) { System.out.println(producto); }
		 * 
		 * System.out.println(":: "); productos.forEach(System.out::println);
		 * 
		 * System.out.println("forEach :: "); productos.forEach(z -> {
		 * System.out.println(z); });
		 */

		/*
		 * System.out.println("forEach :: ");
		 * 
		 * productos.forEach(k -> {
		 * 
		 * if (k.getStock() > 2) { System.out.println(k); }
		 * 
		 * });
		 */
		productos.forEach(System.out::println);

		//double val = productos.stream().mapToDouble(p -> p.getPrecio() * p.getStock()).sum();
		//System.out.println(val);

		// OptionalDouble valx = productos.stream().mapToDouble(p -> p.getPrecio()
		// ).average();
		// System.out.println(valx);

		//double val1 = productos.stream().mapToDouble(p -> p.getPrecio() * p.getStock()).filter(total -> total > 1500)
		//		.sum();
		//System.out.println(val1);
		//double val1x = productos.stream().filter(p -> p.getStock() == 3).mapToDouble(p -> p.getPrecio() * p.getStock())
		//		.sum();

		//System.out.println(val1x);

		double val2 = productos.stream().mapToDouble(p -> (p.getPrecio() * 1.10) * p.getStock())
				.filter(precio -> precio > 200).sum();
		
		double val3 = productos.stream().mapToDouble(p -> (p.getPrecio() * 0.90) * p.getStock())
				.filter(precio -> precio > 200).sum();

		//System.out.println(val2);

		System.out.println(val3 - val2);

	}
}
