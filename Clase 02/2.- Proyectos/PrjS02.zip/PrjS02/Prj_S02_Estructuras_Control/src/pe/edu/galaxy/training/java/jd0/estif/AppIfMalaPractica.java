package pe.edu.galaxy.training.java.jd0.estif;

public class AppIfMalaPractica {

	public static void main(String[] args) {

		float nota = 5.8f;

		if (nota >= 10.5) /*{*/
			System.out.println("Aprobado");
			System.out.println("Darle beca");
		/*}*/
	}

}
