
package pe.edu.galaxy.training.java.albums.persistencia.impl;

public class BaseDAOImpl {
    
    
}
