package pe.edu.galaxy.training.java.jd0.estif;

public class AppIfErrorSintaxis {

	public static void main(String[] args) {

		float nota = 0.6f;

		if (nota >= 10.5); 
		
		{
			System.out.println("Aprobado");
		} 

	}

}
