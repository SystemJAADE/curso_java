package pe.edu.galaxy.training.java.jd0.estwhile;

public class AppWhile {

	public static void main(String[] args) {

		int i = 20;
		while (i < 10) {

			System.out.println(i);
			i++;
		}

		System.out.println();
		/*
		i = 10;

		while (i > 0) {
			i--;
			System.out.println(i);

		}
		System.out.println();
		
		i=0;
		while (i < 10) {

			System.out.println(i);
			i+=2;
		}
	*/
	}
}
