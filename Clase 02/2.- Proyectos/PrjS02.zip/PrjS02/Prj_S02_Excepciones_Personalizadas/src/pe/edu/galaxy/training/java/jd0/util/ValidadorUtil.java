package pe.edu.galaxy.training.java.jd0.util;

import pe.edu.galaxy.training.java.jd0.excepciones.ValidadorException;

public class ValidadorUtil {

	public static boolean dni(String dni) throws ValidadorException{

		if (dni.length() != 8) {
			throw new ValidadorException("El dni debe tener 8 d�gitos, usted ingres� " + dni.length() + " d�gitos");
		}
		
		for (int i = 0; i < dni.length(); i++) {
			char c=dni.charAt(i);
			if (!Character.isDigit(c)) {
				throw new ValidadorException("El caracter "+ c + " no es v�lido");
			}
		}
		return true;
	}

	public  boolean ruc(String dni) {
		/*
		 *  Debe tener 11 digitos  y comenzar con 20,10 o 17
		 */
		return false;
	}

	public  boolean correo(String dni) {
		/*
		 * Deber tener dominio,@ y sin caracteres especiales 
		 */
		return false;
	}

	public  boolean clave(String dni) {
		/*
		 * Minimo 8 carateres, numeros, letras mayuscuals y minusculas, especiales (%$#@+.-(*&)
		 */
		return false;
	}
}
