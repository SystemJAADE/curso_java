package pe.edu.galaxy.training.java.jd0.app.dimension1;

public class AppD1F {

	public static void main(String[] args) {
		
		//1.- Declaraci�n,Instanciaci�n (new),Inicializaci�n
		
		String frutas[]= {"Pi�a","Naranja","Uva","Fresa","Platano","Pera"};
			
		for (String f : frutas) {
			System.out.println(f);
		}
		
	}

}
