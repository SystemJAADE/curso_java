package pe.edu.galaxy.training.java.jd0.estif;

public class AppIfElse {

	public static void main(String[] args) {
		
		float nota=10.6f;
		
		if (nota>=10.5) {
			System.out.println("Aprobado");
		}else {
			System.out.println("Desaprobado");
		}

	}

}
