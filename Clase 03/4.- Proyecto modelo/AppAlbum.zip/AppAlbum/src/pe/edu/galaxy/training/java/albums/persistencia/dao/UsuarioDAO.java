
package pe.edu.galaxy.training.java.albums.persistencia.dao;

import pe.edu.galaxy.training.java.albums.beans.UsuarioBean;
import pe.edu.galaxy.training.java.albums.persistencia.exception.PersistenciaException;

public interface UsuarioDAO extends BaseDAO<UsuarioBean>{
    
    //Login
    public UsuarioBean validarAcceso(UsuarioBean usuarioBean) throws PersistenciaException;
    
    public boolean cambiarClave(UsuarioBean usuarioBean) throws PersistenciaException;
}
