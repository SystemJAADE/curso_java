package pe.edu.galaxy.training.java.jd0.estfor;

public class AppForCasoMejora1 {
	
	public static void main(String[] args) {

		String dni = "910616987";
		
		if (dni.length()==8) {
			if (validar(dni)) {
				System.out.println(dni + " v�lido");
			}else {
				System.out.println(dni + " inv�lido");
			}
		}else {
			System.out.println("El dni debe tener 8 d�gitos, usted ingres� "+ dni.length() + " d�gitos");
		}
		
	}
	
	private static boolean validar(String dni) {
		for (int i = 0; i < dni.length(); i++) {
			System.out.println(dni.charAt(i));
			if (!Character.isDigit(dni.charAt(i))) {
				return false;
			}
		}
		return true;
	}
}
