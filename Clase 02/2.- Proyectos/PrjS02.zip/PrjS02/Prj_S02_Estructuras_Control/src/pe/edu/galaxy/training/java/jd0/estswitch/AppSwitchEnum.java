package pe.edu.galaxy.training.java.jd0.estswitch;

public class AppSwitchEnum {

	public static void main(String[] args) {

		/* Entero, char, String, Enum */

		ClienteEnum tipo = ClienteEnum.SILVER;

		switch (tipo) {
		case GOLD: {
			System.out.println("dscto 20%");
			break;
		}
		case SILVER: {
			System.out.println("dscto 10%");
			break;
		}

		case PLATINUM: {
			System.out.println("dscto 8%");
			break;
		}

		default:
			System.out.println("No v�lido");
			break;
		}
	}

}
