package pe.edu.galaxy.training.java.jd0.list;

import java.util.ArrayList;
import java.util.List;

public class AppList {

	public static void main(String[] args) {
		
		
		List<String> frutas= new ArrayList<>();
		
		frutas.add("Pera");
		frutas.add("Pi�a");
		frutas.add("Manana");
		frutas.add("Papaya");
		
		for (int i = 0; i < frutas.size(); i++) {
			System.out.println(frutas.get(i));
		}

		System.out.println();
		
		for (String fruta : frutas) { // For each
			System.out.println(fruta);
		}
		
		System.out.println();
		frutas.forEach(System.out::println);
		
		
	}

}
