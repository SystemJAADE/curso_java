package pe.edu.galaxy.training.java.jd0.clases;

public class Importador extends Empresa{

	private String pais;
	
}
