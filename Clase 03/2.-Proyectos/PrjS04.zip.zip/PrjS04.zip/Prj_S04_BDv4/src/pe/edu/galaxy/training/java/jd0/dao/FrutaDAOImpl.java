package pe.edu.galaxy.training.java.jd0.dao;

import java.util.List;
import pe.edu.galaxy.training.java.jd0.beans.Fruta;

public class FrutaDAOImpl implements FrutaDAO{

	public FrutaDAOImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public List<Fruta> listar() {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public List<Fruta> listar(Fruta fruta) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public Boolean insertar(Fruta fruta) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Boolean actualizar(Fruta fruta) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Boolean eliminar(Integer codigo) {
		// TODO Auto-generated method stub
		return null;
	}

	
}
