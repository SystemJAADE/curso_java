package pe.edu.galaxy.training.java.jd0.expresiones;

public class AppExpresiones {

	public static void main(String[] args) {
		
		
		String dni="91061698";
		
		boolean sw=true;
		
		for (int i = 0; i < dni.length(); i++) {
			System.out.println(dni.charAt(i));
			if (!Character.isDigit(dni.charAt(i))) {
				System.err.println("Error - dni no valido");
				sw=false;
				break;
			}
		}
		if (sw) {
			System.out.println("Dni correcto");
		}
		
		
		if (dni.matches("[0-9]*")) {
			System.out.println("Dni correcto");
		}else {
			System.out.println("Dni incorrecto");
		}
		
	}

}
