package pe.edu.galaxy.training.java.jd0;

public class AppDemo {

	public static void main(String args[]){

		System.out.println("Java B�sico");
		System.out.print(2021);
		System.out.print(" Octubre");

		System.out.println("\nClase 01");	// Salto de linea
		System.out.println("\rClase 01");	// Retorno de carro
		System.out.println("\tClase 01"); 	// Tabulaci�n 
		
		System.out.println("Fin");
	}
}
