package pe.edu.galaxy.training.java.jd0.caso.dao;

import pe.edu.galaxy.training.java.jd0.caso.beans.ProductoBean;

public interface ProductoDAO extends BaseDAO<ProductoBean>{

}
