package pe.edu.galaxy.training.java.albums.util;

import java.sql.Connection;
import java.sql.DriverManager;

public class BD {
    private static String driver = "oracle.jdbc.OracleDriver";
	private static String url = "jdbc:oracle:thin:@127.0.0.1:1521:XE";
	private static String usuario = "JD015";
	private static String clave = "123456";

	private static boolean cargarDriver() {
		try {
			Class.forName(driver);
			//System.out.println("Exito al cargar el driver");
			return true;
		} catch (Exception e) {
			System.err.println("Error al cargar el driver  " + e.getMessage());
			return false;
		}
	}

	public static Connection conectar() {

		if (!cargarDriver()) {
			return null;
		}
		try {
			Connection cn = DriverManager.getConnection(url, usuario, clave);
			//System.out.println("Exito al conectar");
			return cn;
		} catch (Exception e) {
			System.err.println("Error al conectar  " + e.getMessage());
			return null;
		}
	}
}
