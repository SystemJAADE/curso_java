package pe.edu.galaxy.training.java.jd0.caso.dao;

import java.util.List;
import java.util.Optional;

public interface BaseDAO<T> {

	List<T> findByLike(T t) throws DAOException;
	
	Optional<T> findById(T t) throws DAOException;
	
	T save(T t) throws DAOException;
	
}
