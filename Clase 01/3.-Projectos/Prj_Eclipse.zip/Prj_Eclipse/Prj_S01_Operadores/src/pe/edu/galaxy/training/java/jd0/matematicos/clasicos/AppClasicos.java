package pe.edu.galaxy.training.java.jd0.matematicos.clasicos;

public class AppClasicos {

	public static void main(String[] args) {
		
		// +,-,/, *, %
		
		short a=1000, b=300;
		
		System.out.println(a+b);
		System.out.println(a-b);
		System.out.println(a/b);
		System.out.println(a*b);
		System.out.println(a%b); // m�dulo
		
		System.out.println((float)a/b);
		System.out.println(a/(float)b);
		

	}

}
