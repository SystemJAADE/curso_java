package pe.edu.galaxy.training.java.jd0.relacionales;

public class AppRelacional {

	public static void main(String[] args) {
		
		// &&->and, || or, not !
		
		int edad=15; // Asignaci�n
		String genero="M";
		
		if (edad==18 && genero.equals("M")) { //Comparaci�n
			System.out.println("Caballero");
		} else {
			System.out.println("Adolecente");
		}
		
		if (edad==18 & genero.equals("M")) { //Comparaci�n
			System.out.println("Caballero");
		} else {
			System.out.println("Adolecente");
		}

		
		
		if (edad==18 || genero.equals("M")) { //Comparaci�n
			System.out.println("Independiente");
		} else {
			System.out.println("Adolecente");
		}
		
		if (!(edad==18 || genero.equals("M"))) { //Comparaci�n
			System.out.println("Independiente");
		} else {
			System.out.println("Adolecente");
		}
		
		System.out.println(true);
		
		System.out.println(!true);
	}

}
