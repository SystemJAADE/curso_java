package pe.edu.galaxy.training.java.jd0;

public class AppDemo03 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
