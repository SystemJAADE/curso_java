package pe.edu.galaxy.training.java.jd0.objetos;

public class MyString /*extends String*/{

	public MyString() {
		// TODO Auto-generated constructor stub
	}

}
