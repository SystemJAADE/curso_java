package pe.edu.galaxy.training.java.pf.predicate;

import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;

public class AppPredicate {

	public static void main(String[] args) {

		List<String> talleres = Arrays.asList("Java", "Java Cero", "Net", "Android", "App Java Web","Otros");

		/*
		Predicate<String> p1 = (taller) -> taller.startsWith("Java"); // V / F

		for (String t : talleres) {
			if (p1.test(t)) {
				System.out.println(t);
			}
		}
		*/
		Predicate<String> p1 = (taller) -> taller.indexOf("Java")>=0; // V / F

		for (String t : talleres) {
			if (p1.test(t)) {
				System.out.println(t);
			}
		}
	}

}
