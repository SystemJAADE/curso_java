package pe.edu.galaxy.training.java.jd0.caso.beans;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@SuperBuilder
@Data
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@AllArgsConstructor
public class ProductoBean extends BaseBean{

	private String nombre;
	
	private String descripcion;
	
	private Double precio;
	
	private Integer stockActual;
	
	private Integer stockMinimo;
	
	private Integer stockMaximo;
		
}
