
package pe.edu.galaxy.training.java.albums.beans;

public class UsuarioBean extends BaseBean{
    
    private String usuario;
    private String clave;
    private String nombre;

    public UsuarioBean() {
    }

    public UsuarioBean(Long codigo,String usuario, String clave ) {
        super(codigo);
        this.usuario = usuario;
        this.clave = clave;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Long getCodigo() {
        return codigo;
    }

    public void setCodigo(Long codigo) {
        this.codigo = codigo;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    @Override
    public String toString() {
        return "UsuarioBean{" + "usuario=" + usuario + ", clave=" + clave + ", nombre=" + nombre + '}';
    }
    
    
    
}
