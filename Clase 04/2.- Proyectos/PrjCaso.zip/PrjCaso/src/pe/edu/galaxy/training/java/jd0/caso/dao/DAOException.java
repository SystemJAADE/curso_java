package pe.edu.galaxy.training.java.jd0.caso.dao;

public class DAOException extends Exception{

	private static final long serialVersionUID = -5879369686263723182L;

	public DAOException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public DAOException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public DAOException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public DAOException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public DAOException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	

}
