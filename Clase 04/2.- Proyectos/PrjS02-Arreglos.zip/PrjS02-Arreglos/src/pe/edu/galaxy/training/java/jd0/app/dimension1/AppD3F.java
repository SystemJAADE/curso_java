package pe.edu.galaxy.training.java.jd0.app.dimension1;

public class AppD3F {

	public static void main(String[] args) {
		
		//1.- Declaraci�n
		
		String frutas[];
		
		int [] dias;
		
		
		//2.- Instanciaci�n (new)
		
		frutas=new String[5]; // reserva
		
		
		//3.- Inicailizaci�n
		
		frutas[0]= "Pi�a";
		frutas[1]= "Naranja";
		frutas[2]= "Uva";
		frutas[3]= "Fresa";
		
		frutas[4]= "Platano";
		
		System.out.println(frutas[4]);

		// Primitiva
		for (int i = 0; i < frutas.length; i++) {
			System.out.println(frutas[i]);
		}
		
		
		System.out.println("for each");
		
		for (String f : frutas) {
			System.out.println(f);
		}
		
		
	}

}
