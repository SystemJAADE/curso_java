package pe.edu.galaxy.training.java.jd0.estfor;

public class AppForCasoMejora2 {

	public static void main(String[] args) {

		String dni = "9x061698";

		if (dni.length() != 8) {
			System.out.println("El dni debe tener 8 d�gitos, usted ingres� " + dni.length() + " d�gitos");
			return;
		}

		System.out.println(dni + ((validar(dni)) ? " v�lido" : " inv�lido"));// (condicional)?V:F

	}

	private static boolean validar(String dni) {
		for (int i = 0; i < dni.length(); i++) {
			if (!Character.isDigit(dni.charAt(i))) {
				return false;
			}
		}
		return true;
	}
}
