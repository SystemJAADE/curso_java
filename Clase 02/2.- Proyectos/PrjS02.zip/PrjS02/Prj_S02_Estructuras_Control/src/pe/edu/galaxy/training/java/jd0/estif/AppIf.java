package pe.edu.galaxy.training.java.jd0.estif;

public class AppIf {

	public static void main(String[] args) {
		
		float nota=10.0f;
		
		if (nota>=10.5) {
			System.out.println("Aprobado");
		}

	}

}
