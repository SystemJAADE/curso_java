package pe.edu.galaxy.training.java.pf.predicate;

import java.util.List;
import java.util.function.Predicate;
import pe.edu.galaxy.training.java.pf.beans.Producto;
import pe.edu.galaxy.training.java.pf.service.ProductoService;
import pe.edu.galaxy.training.java.pf.service.ProductoServiceImpl;


public class AppPredicateProductos {

	public static void main(String[] args) {
		
		ProductoService ps= new ProductoServiceImpl();
		
		List<Producto> productos = ps.getAll();
		
		productos.forEach(System.out::println);
		
		Predicate<Producto> mayor = p -> (p.getStock() == 3);

		double d = productos.stream().filter(mayor).mapToDouble(p -> p.getPrecio()*p.getStock()).sum();
		System.out.println(d);


	}

}
