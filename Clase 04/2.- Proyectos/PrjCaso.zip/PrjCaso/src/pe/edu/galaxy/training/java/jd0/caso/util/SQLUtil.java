package pe.edu.galaxy.training.java.jd0.caso.util;

//import java.util.Objects;

import static java.util.Objects.isNull;

public class SQLUtil {

	public static String getLike(String str) {

		if (isNull(str)) {
			str = "";
		}
		return "%" + str + "%";
	}

}
