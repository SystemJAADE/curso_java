package pe.edu.galaxy.training.java.jd0.app.dimension3;

public class AppD2F {

	public static void main(String[] args) {
	
		String frutas[][][]=new String[3][2][2];

		frutas[0][0][0]= "Pi�a";
		frutas[0][0][1]= "2";
		frutas[0][0][1]= "1";
		
	}

}
