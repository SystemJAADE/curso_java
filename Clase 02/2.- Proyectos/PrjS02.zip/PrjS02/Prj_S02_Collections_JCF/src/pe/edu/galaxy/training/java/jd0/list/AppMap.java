package pe.edu.galaxy.training.java.jd0.list;

import java.util.HashMap;
import java.util.Map;

public class AppMap {

	public static void main(String[] args) {
		
		
		Map<String ,String> frutas= new HashMap<>();
		
		frutas.put("P1", "Pera");
		frutas.put("P2","Pi�a");
		frutas.put("M1","Manana");
		frutas.put("P3","Papaya");
		frutas.put("P4","Pera");
		
		System.out.println();

		System.out.println(frutas.get("P4"));
		
		for (String key : frutas.keySet()) {
			System.out.println(frutas.get(key));
		}
		
	}

}
