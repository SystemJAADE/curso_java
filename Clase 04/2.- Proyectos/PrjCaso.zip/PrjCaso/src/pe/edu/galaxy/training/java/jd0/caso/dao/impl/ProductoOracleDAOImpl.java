package pe.edu.galaxy.training.java.jd0.caso.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import pe.edu.galaxy.training.java.jd0.caso.beans.ProductoBean;
import pe.edu.galaxy.training.java.jd0.caso.dao.DAOException;
import pe.edu.galaxy.training.java.jd0.caso.dao.ProductoDAO;
import pe.edu.galaxy.training.java.jd0.caso.util.BD;
import static pe.edu.galaxy.training.java.jd0.caso.util.SQLUtil.getLike;

public class ProductoOracleDAOImpl implements ProductoDAO{

	@Override
	public List<ProductoBean> findByLike(ProductoBean productoBean) throws DAOException {
		try {
			Connection cn = BD.getConnection();
			String sql = "SELECT ID_PRODUCTO,NOMBRE,DESCRIPCION,PRECIO,"
					+ " STOCK_ACTUAL, STOCK_MINIMO,STOCK_MAXIMO"
					+ " FROM PRODUCTO WHERE UPPER(NOMBRE) LIKE UPPER(?) AND ESTADO='1'";
			PreparedStatement ps = cn.prepareStatement(sql);
			ps.setString(1,getLike(productoBean.getNombre()));
			ResultSet rs = ps.executeQuery();
			List<ProductoBean> productos = new ArrayList<>();

			while (rs.next()) {
				productos.add(ProductoBean.builder()
						.codigo(rs.getLong("ID_PRODUCTO"))
						.nombre(rs.getString("NOMBRE"))
						.descripcion(rs.getString("DESCRIPCION"))
						.stockActual(rs.getInt("STOCK_ACTUAL"))
						.build());
			}
			rs.close();
			ps.close();
			cn.close();
			return productos;

		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public Optional<ProductoBean> findById(ProductoBean t) throws DAOException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ProductoBean save(ProductoBean t) throws DAOException {
		// TODO Auto-generated method stub
		return null;
	}
}
