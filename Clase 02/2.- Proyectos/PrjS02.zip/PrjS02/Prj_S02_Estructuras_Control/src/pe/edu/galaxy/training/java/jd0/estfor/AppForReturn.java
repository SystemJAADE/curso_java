package pe.edu.galaxy.training.java.jd0.estfor;

public class AppForReturn {

	public static void main(String[] args) {

		for (int i = 0; i < 10; i++) {
			if (i==5) {
				return;
			}
			System.out.println(i);
		}
		System.out.println("fin...");
	}

}
