
package pe.edu.galaxy.training.java.albums.persistencia.dao;

import java.util.List;
import pe.edu.galaxy.training.java.albums.persistencia.exception.PersistenciaException;


public interface BaseDAO<T> {
    
    public List<T> listar(T t) throws PersistenciaException;
    
    public T buscarXCodigo(T t) throws PersistenciaException;
    
    public boolean insertar(T t)throws PersistenciaException;
    
    public boolean actualizar(T t)throws PersistenciaException;

    public boolean eliminar(T t)throws PersistenciaException;

}
