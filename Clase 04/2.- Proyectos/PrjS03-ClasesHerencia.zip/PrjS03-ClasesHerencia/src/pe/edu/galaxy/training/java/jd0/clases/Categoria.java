package pe.edu.galaxy.training.java.jd0.clases;

public class Categoria extends Generico{

	private String nombre;
	
	public Categoria() {
		super();
	}

	public Categoria(Integer codigo, String nombre) {
		super(codigo);
		this.nombre = nombre;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	@Override
	public String toString() {
		return "Categoria [nombre=" + nombre + ", toString()=" + super.toString() + "]";
	}
	
}
