package pe.edu.galaxy.training.java.jd0.beans;

public class Generico {

	protected Integer codigo;

	public Generico() {

	}

	public Generico(Integer codigo) {
		this.codigo = codigo;
	}

	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}

	public Integer getCodigo() {
		return codigo;
	}

}
