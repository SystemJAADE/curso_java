package pe.edu.galaxy.training.java.jd0.dao.impl.oracle;

import java.sql.SQLException;
import java.util.List;
import pe.edu.galaxy.training.java.jd0.beans.Cliente;
import pe.edu.galaxy.training.java.jd0.dao.ClienteDAO;

public class ClienteDAOImpl implements ClienteDAO{

	public ClienteDAOImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public List<Cliente> listar() throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Cliente> listar(Cliente t) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Boolean insertar(Cliente t) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Boolean actualizar(Cliente t) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Boolean eliminar(Integer codigo) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

}
