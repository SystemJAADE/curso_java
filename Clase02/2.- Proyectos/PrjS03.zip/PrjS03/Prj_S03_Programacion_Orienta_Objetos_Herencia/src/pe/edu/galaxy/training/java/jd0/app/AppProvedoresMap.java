package pe.edu.galaxy.training.java.jd0.app;

import java.util.HashMap;
import java.util.Map;

import pe.edu.galaxy.training.java.jd0.beans.Provedor;

public class AppProvedoresMap {

	public static void main(String[] args) {
		
		// Coleccion
		
		Map<Integer, Provedor> provedores = new HashMap<>();
		Provedor provedor=new Provedor(100, "Productos Amazonences", "2054987254");
		provedores.put(100, provedor);
		provedores.put(200,new Provedor(200, "Inversiones la Cruz", "1054987200"));

		System.out.println(provedores.get(200));
		
	}

}
