package pe.edu.galaxy.training.java.albums.persistencia.impl;

import java.util.List;
import pe.edu.galaxy.training.java.albums.beans.UsuarioBean;
import pe.edu.galaxy.training.java.albums.persistencia.dao.UsuarioDAO;
import pe.edu.galaxy.training.java.albums.persistencia.exception.PersistenciaException;

public class UsuarioDAOImpl
        extends BaseDAOImpl
        implements UsuarioDAO {

    @Override
    public List<UsuarioBean> listar(UsuarioBean t) throws PersistenciaException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public UsuarioBean buscarXCodigo(UsuarioBean t) throws PersistenciaException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean insertar(UsuarioBean t) throws PersistenciaException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean actualizar(UsuarioBean t) throws PersistenciaException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean eliminar(UsuarioBean t) throws PersistenciaException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public UsuarioBean validarAcceso(UsuarioBean usuarioBean) throws PersistenciaException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean cambiarClave(UsuarioBean usuarioBean) throws PersistenciaException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
