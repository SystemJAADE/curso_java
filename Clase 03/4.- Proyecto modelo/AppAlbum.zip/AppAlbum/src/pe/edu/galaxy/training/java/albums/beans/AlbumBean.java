
package pe.edu.galaxy.training.java.albums.beans;

public class AlbumBean extends BaseBean {
    
     private String nombre;
     private String descripcion;

    public AlbumBean() {
    }

    public AlbumBean(Long codigo) {
        super(codigo);
    }

 
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    @Override
    public String toString() {
        return "AlbumBean{" + "nombre=" + nombre + ", descripcion=" + descripcion + '}';
    }

    
}
