package pe.edu.galaxy.training.java.jd0.dao;

import pe.edu.galaxy.training.java.jd0.beans.Fruta;

public interface FrutaDAO extends GenericoDAO<Fruta>{

	
}
