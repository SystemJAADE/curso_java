package pe.edu.java.galaxy.training;

public class AppMyHilo {

	public static void main(String[] args) {

		StringBuffer msg = new StringBuffer("Galaxy Training -");

		long inicio = System.currentTimeMillis();

		for (int i = 0; i < msg.length(); i++) {
			System.out.println(msg.charAt(i));
		}

		long termino = System.currentTimeMillis();

		System.out.println(termino - inicio);
		
	
		inicio = System.currentTimeMillis();
		
		MyHilo myHilo1 = new MyHilo("H1", msg);

		MyHilo myHilo2 = new MyHilo("H2", msg);

		inicio = System.currentTimeMillis();

		myHilo1.start();
		myHilo2.start();

		termino = System.currentTimeMillis();

		System.out.println("T >:" + (termino - inicio));
		
	}

}
