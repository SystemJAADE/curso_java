package pe.edu.galaxy.training.java.jd0.app;

import pe.edu.galaxy.training.java.jd0.excepciones.ValidadorException;
import pe.edu.galaxy.training.java.jd0.util.ValidadorUtil;

public class AppValidadorUtil {

	public static void main(String[] args) {
				
		String dni = "x98061698";

		try {
			
			System.out.println(dni + ((ValidadorUtil.dni(dni)) ? " v�lido" : " inv�lido"));
			
		} catch (ValidadorException e) {
			System.err.println(e.getMessage());
			//e.printStackTrace();
		}

	}

}
