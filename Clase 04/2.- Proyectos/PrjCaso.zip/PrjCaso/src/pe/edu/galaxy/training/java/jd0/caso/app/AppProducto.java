package pe.edu.galaxy.training.java.jd0.caso.app;

import pe.edu.galaxy.training.java.jd0.caso.beans.ProductoBean;
import pe.edu.galaxy.training.java.jd0.caso.dao.ProductoDAO;
import pe.edu.galaxy.training.java.jd0.caso.dao.impl.ProductoOracleDAOImpl;

public class AppProducto {

	public static void main(String[] args) {
	
		try {
			ProductoDAO productoDAO= new ProductoOracleDAOImpl();
			
			productoDAO.findByLike(new ProductoBean()).forEach(System.out::println);
		} catch (Exception e) {
			e.printStackTrace();
		}
		

	}

}
