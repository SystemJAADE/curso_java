
package pe.edu.galaxy.training.java.albums.persistencia.dao;

import pe.edu.galaxy.training.java.albums.beans.AlbumBean;

public interface AlbumDAO extends BaseDAO<AlbumBean>{
   
}
