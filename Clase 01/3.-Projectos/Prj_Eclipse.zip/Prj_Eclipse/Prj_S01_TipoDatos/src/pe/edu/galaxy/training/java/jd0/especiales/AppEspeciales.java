package pe.edu.galaxy.training.java.jd0.especiales;

import java.math.BigDecimal;

public class AppEspeciales {

	public static void main(String[] args) {
		
		boolean sw=false;
		
		Boolean sw1=true;
		
		System.out.println(sw);
		System.out.println(sw1);
		System.out.println(!Boolean.valueOf("true"));
		
		char c='x';
		System.out.println(c);
		
		System.out.println(Character.isDigit('1'));
		
		System.out.println(Character.isLetter('x'));
		
		
		BigDecimal bd= new BigDecimal("100000.123");
		
		System.out.println(bd.floatValue());
		
		System.out.println(bd.multiply(new BigDecimal(2.0)));
		
	}
}
