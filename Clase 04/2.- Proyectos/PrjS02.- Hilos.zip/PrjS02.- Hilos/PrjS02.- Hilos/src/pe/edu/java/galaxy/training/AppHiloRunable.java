package pe.edu.java.galaxy.training;

import java.io.Serializable;

public class AppHiloRunable extends Object implements Runnable, Serializable {

    private String nombre;
    
    public AppHiloRunable(String nombre){
        this.nombre=nombre;
    }

    public static void main(String[] args) {
    	
    	AppHiloRunable h1=new AppHiloRunable("H1");
    	
    	AppHiloRunable h2=new AppHiloRunable("H2");
    	
    	Thread thread1 = new Thread(h1);  
    	thread1.start();  
    	
    	Thread thread2 = new Thread(h2);  
    	thread2.start();  
    	
    	//thread1.run();
    	//thread2.run();
    
        
    }

	@Override
	public void run() {
		  for (int i = 0; i < 10; i++) {
	            System.out.println(this.nombre+ " "+ i);
	        }
		
	}
   
}
