package pe.edu.galaxy.training.java.jd0.objetos;

import pe.edu.galaxy.training.java.jd0.clases.Categoria;
import pe.edu.galaxy.training.java.jd0.clases.Producto;

public class AppProducto {

	public static void main(String[] args) {
		
		// Clase objeto		   constructor
		
		Producto producto= new Producto();
		
		producto.setCodigo(100);
		producto.setNombre("Laptop ASUS");
		producto.setPrecio(3500.0);
		producto.setStock(2);
		
		Categoria categoria= new Categoria(1,"Equipos de C�mputo");
		
		producto.setCategoria(categoria);		

		Producto producto1= new Producto(200, "Impresora Epson 565",900.0,3);
		producto1.setCategoria(categoria);
		
		
		Producto producto2= new Producto(300, "Millar de hojas bond",250.0,-4,false);	
		producto2.setCategoria(new Categoria(2,"Utiles de oficina"));
	
		System.out.println(producto);
		System.out.println(producto1);
		System.out.println(producto2);
	}
}
