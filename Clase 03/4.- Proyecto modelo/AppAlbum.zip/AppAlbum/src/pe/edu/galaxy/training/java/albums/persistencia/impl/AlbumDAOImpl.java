package pe.edu.galaxy.training.java.albums.persistencia.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import pe.edu.galaxy.training.java.albums.beans.AlbumBean;
import pe.edu.galaxy.training.java.albums.persistencia.dao.AlbumDAO;
import pe.edu.galaxy.training.java.albums.persistencia.exception.PersistenciaException;
import pe.edu.galaxy.training.java.albums.util.BD;

public class AlbumDAOImpl
        extends BaseDAOImpl
        implements AlbumDAO {

    @Override
    public List<AlbumBean> listar(AlbumBean prmAlbumBean) throws PersistenciaException {
        try {
            Connection cn = BD.conectar();
            String sql = "SELECT CODIGO,NOMBRE,DESCRIPCION FROM ALBUM"
                    + " WHERE UPPER(NOMBRE) LIKE UPPER(?)"
                    + " AND ESTADO='1'";
            PreparedStatement ps = cn.prepareStatement(sql);
            ps.setString(1, "%" + prmAlbumBean.getNombre() + "%");
            ResultSet rs = ps.executeQuery();
            List<AlbumBean> lst = new ArrayList<>();
            while (rs.next()) {
                AlbumBean albumBean = new AlbumBean();
                albumBean.setCodigo(rs.getLong("CODIGO"));
                albumBean.setNombre(rs.getString("NOMBRE"));
                albumBean.setDescripcion(rs.getString("DESCRIPCION"));

                lst.add(albumBean);
            }
            rs.close();
            ps.close();
            cn.close();
            return lst;
        } catch (Exception e) {
            throw new PersistenciaException("Error al listar albums" + e);
        }
    }

    @Override
    public AlbumBean buscarXCodigo(AlbumBean t) throws PersistenciaException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean insertar(AlbumBean prmAlbumBean) throws PersistenciaException {

        try {
            Connection cn = BD.conectar();
            String sql = "INSERT INTO ALBUM(CODIGO,NOMBRE,DESCRIPCION)"
                    + " VALUES(SEQ_ALBUM.NEXTVAL,?,?)";
            PreparedStatement ps = cn.prepareStatement(sql);
            ps.setString(1, prmAlbumBean.getNombre());
            ps.setString(2, prmAlbumBean.getDescripcion());

            ps.executeUpdate();

            ps.close();
            cn.close();
            return true;
        } catch (Exception e) {
            throw new PersistenciaException("Error al insertar albums" + e);
        }

    }

    @Override
    public boolean actualizar(AlbumBean prmAlbumBean) throws PersistenciaException {
        try {
            Connection cn = BD.conectar();
            String sql = "UPDATE ALBUM"
                    + " SET NOMBRE=?,"
                    + "     DESCRIPCION=?"
                    + " WHERE CODIGO=?";
            PreparedStatement ps = cn.prepareStatement(sql);
            ps.setString(1, prmAlbumBean.getNombre());
            ps.setString(2, prmAlbumBean.getDescripcion());
            ps.setLong(3, prmAlbumBean.getCodigo());

            ps.executeUpdate();

            ps.close();
            cn.close();
            return true;
        } catch (Exception e) {
            throw new PersistenciaException("Error al actualizar albums" + e);
        }
    }

    @Override
    public boolean eliminar(AlbumBean prmAlbumBean) throws PersistenciaException {
        try {
            Connection cn = BD.conectar();
            String sql = "UPDATE ALBUM"
                    + " SET ESTADO='0'"
                    + " WHERE CODIGO=?";
            PreparedStatement ps = cn.prepareStatement(sql);

            ps.setLong(1, prmAlbumBean.getCodigo());

            ps.executeUpdate();

            ps.close();
            cn.close();
            return true;
        } catch (Exception e) {
            throw new PersistenciaException("Error al actualizar albums" + e);
        }

    }

}
