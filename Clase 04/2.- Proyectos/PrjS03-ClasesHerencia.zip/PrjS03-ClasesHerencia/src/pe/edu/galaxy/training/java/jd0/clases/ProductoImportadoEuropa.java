package pe.edu.galaxy.training.java.jd0.clases;

public class ProductoImportadoEuropa extends ProductoImportado{

}
