package pe.edu.galaxy.training.java.jd0.caso.beans;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@AllArgsConstructor
public class ProveedorBean extends BaseBean{

	private String razonSocial;
	
	private String ruc;
	
}
