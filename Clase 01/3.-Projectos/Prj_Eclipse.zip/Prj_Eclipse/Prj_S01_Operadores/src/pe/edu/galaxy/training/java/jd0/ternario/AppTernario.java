package pe.edu.galaxy.training.java.jd0.ternario;

public class AppTernario {

	public static void main(String[] args) {
		
		short nota =20;
		
		if (nota>=10.5) {
			System.out.println("Aprobado");
		}else {
			System.out.println("Desaprobado");
		}
		
		System.out.println((nota>=10.5)?"Aprobado":"Desaprobado");
		
		System.out.println((nota>=10.5)?((nota==20)?"Excelente":"Aprobado"):"Desaprobado");
		
	}

}
