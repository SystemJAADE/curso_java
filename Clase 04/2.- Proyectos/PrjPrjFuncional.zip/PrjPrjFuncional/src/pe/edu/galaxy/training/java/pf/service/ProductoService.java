package pe.edu.galaxy.training.java.pf.service;

import java.util.List;

import pe.edu.galaxy.training.java.pf.beans.Producto;

// Interface clasica
public interface ProductoService {

	List<Producto> getAll();
	
	Producto findById(Integer id);
	
}
