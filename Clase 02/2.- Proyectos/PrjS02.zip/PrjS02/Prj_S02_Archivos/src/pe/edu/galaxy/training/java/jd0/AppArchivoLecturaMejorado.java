package pe.edu.galaxy.training.java.jd0;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class AppArchivoLecturaMejorado {
	
	// https://docs.oracle.com/javase/tutorial/essential/io/

	public static void main(String[] args) {
		String archivo = "D:\\tmp\\archivo-java-octubre-2021_a.txt";
		try (FileReader fr = new FileReader(archivo); BufferedReader br = new BufferedReader(fr);) {
			String registro;

			while ((registro = br.readLine()) != null) {
				System.out.println(registro);
			}
		} catch (IOException e) {
			System.err.println(e.getMessage());
			//e.printStackTrace();
		}
	}

}
