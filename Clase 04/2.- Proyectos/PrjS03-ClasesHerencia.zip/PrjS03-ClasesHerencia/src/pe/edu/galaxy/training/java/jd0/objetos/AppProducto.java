package pe.edu.galaxy.training.java.jd0.objetos;

import pe.edu.galaxy.training.java.jd0.clases.Categoria;
import pe.edu.galaxy.training.java.jd0.clases.Generico;
import pe.edu.galaxy.training.java.jd0.clases.Producto;
import pe.edu.galaxy.training.java.jd0.clases.Producto.Componente;

public class AppProducto {

	public static void main(String[] args) {
		
		//Generico generico= new Generico();
		
		// Clase objeto		   constructor
		
		Producto producto= new Producto();
		
		producto.setCodigo(100);
		producto.setNombre("Laptop ASUS");
		producto.setPrecio(3500.0);
		producto.setStock(2);
		
		Categoria categoria= new Categoria(1,"Equipos de C�mputo");
		producto.setCategoria(categoria);		

		Producto producto1= new Producto(200, "Impresora Epson 565",900.0,3);
		producto1.setCategoria(categoria);
		
		Producto producto2= new Producto(300, "Millar de hojas bond",250.0,-4,false);	
		producto2.setCategoria(new Categoria(2,"Utiles de oficina"));
		
		Producto producto3= new Producto(400, "Lapiceros",1.5,2,false);	
		producto3.setCategoria(new Categoria(2,"Utiles de oficina"));
	
		System.out.println(producto);
		System.out.println(producto1);
		System.out.println(producto2);
		
		
		//Generico generico = new Generico(); // Abstract
		
		Producto.Componente componente = producto1.new Componente();
		
		componente.setCodigo(1);
		componente.setNombre("Cartucho de tinta");
		componente.setDescripcion("Tinta original");
		
		 
	}
}
