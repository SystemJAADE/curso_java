package pe.edu.galaxy.training.java.jd0;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class AppArchivoLectura {

	public static void main(String[] args) {

		try {
			String registro;
			String archivo = "D:\\tmp\\archivo-java-octubre-2021.txt";
			FileReader fr = new FileReader(archivo);

			BufferedReader br = new BufferedReader(fr);

			while ((registro = br.readLine()) != null) {
				System.out.println(registro);
			}

			br.close();
			fr.close();

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
