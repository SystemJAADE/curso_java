package pe.edu.galaxy.training.java.pf.interfazfunctional;

import java.util.List;
import pe.edu.galaxy.training.java.pf.beans.Producto;
import pe.edu.galaxy.training.java.pf.service.ProductoService;
import pe.edu.galaxy.training.java.pf.service.ProductoServiceImpl;

public class AppIntFunctional {

	public static void main(String[] args) {
		
		ProductoService ps= new ProductoServiceImpl();
		
		List<Producto> productos = ps.getAll();
		
		productos.forEach(p-> System.out.println(p.total()));
		System.out.println();
		
		Valorizar valorizar= (Producto p)->(p.getPrecio()*.80*p.getStock()); 
		
		productos.forEach(p->{
			System.out.println(valorizar.valorizar(p));			
		});
		
	}
}
