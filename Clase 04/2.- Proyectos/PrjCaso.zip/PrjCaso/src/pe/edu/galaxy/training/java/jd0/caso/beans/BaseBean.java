package pe.edu.galaxy.training.java.jd0.caso.beans;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@SuperBuilder
@Data
@NoArgsConstructor
public class BaseBean {

		private Long codigo;
		private String estado;
}
