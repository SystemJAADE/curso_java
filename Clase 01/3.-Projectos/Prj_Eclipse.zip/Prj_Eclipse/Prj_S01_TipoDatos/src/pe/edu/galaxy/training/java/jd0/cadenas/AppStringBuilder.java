package pe.edu.galaxy.training.java.jd0.cadenas;

public class AppStringBuilder {

	public static void main(String[] args) {

		StringBuilder s = new StringBuilder("Java"); // POO

		System.out.println(s);

		System.out.println(s.append(" B�sico"));

		System.out.println(s.insert(5, "11 "));

		System.out.println(s.replace(5, 7, "17"));

		System.out.println(s.delete(5, 8));

		System.out.println(s.reverse());

		System.out.println(s);
	}

}
