package pe.edu.galaxy.training.java.jd0.estswitch;

public enum ClienteEnum {

	GOLD,
	SILVER,
	PLATINUM

}
