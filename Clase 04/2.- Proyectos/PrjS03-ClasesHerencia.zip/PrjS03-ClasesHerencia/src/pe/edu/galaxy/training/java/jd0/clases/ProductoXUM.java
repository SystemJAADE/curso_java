package pe.edu.galaxy.training.java.jd0.clases;

public class ProductoXUM {

	private Producto producto;
	private UnidadMedida unidadMedida;
	
}
