package pe.edu.galaxy.training.java.jd0;

import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.Scanner;

public class AppArchivoEscrituraMejorada {

	public static void main(String[] args) {

		String file = "D://tmp//archivo-java-octubre-2021_a.txt";

		try (	FileWriter archivo = new FileWriter(file, true);
				PrintWriter pw = new PrintWriter(archivo, true);
				Scanner scanner = new Scanner(System.in);
			) {

			System.out.println("Ingrese un registro:");

			String registro = scanner.nextLine();

			pw.println(registro);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
