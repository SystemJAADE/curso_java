package pe.edu.galaxy.training.java.jd0.clases;

import java.util.List;

public class Categoria {
	// Atributos
	private Integer codigo;
	private String nombre;
	private Boolean activo;
	
	private List<Producto> productos;
	
	public Categoria() {
		super();
		this.activo=true;
	}

	public Categoria(Integer codigo, String nombre) {
		super();
		this.codigo = codigo;
		this.nombre = nombre;
		this.activo=true;
	}

	public Integer getCodigo() {
		return codigo;
	}

	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Boolean getActivo() {
		return activo;
	}

	public void setActivo(Boolean activo) {
		this.activo = activo;
	}

	@Override
	public String toString() {
		return "Categoria [codigo=" + codigo + ", nombre=" + nombre + ", activo=" + activo + "]";
	}
	
	
}
