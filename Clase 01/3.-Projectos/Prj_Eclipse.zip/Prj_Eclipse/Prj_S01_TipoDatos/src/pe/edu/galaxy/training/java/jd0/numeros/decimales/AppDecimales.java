package pe.edu.galaxy.training.java.jd0.numeros.decimales;

public class AppDecimales {

	public static void main(String[] args) {
		
		float f0= (float) 10_898.45;
		float f1= -32_000.45F;
		
		System.out.println(Float.MIN_VALUE +" / "+ Float.MAX_VALUE);
		
		String str1="200000000";
		
		System.out.println(Long.valueOf(str1)+f0);
		
		
		double d0= 10_898_255_455.45;
		double d1= -32_000_788_788.45F;
		
		System.out.println(Double.MIN_VALUE +" / "+ Double.MAX_VALUE);
		
		String str2="20000000045555123";
		
		System.out.println(Long.valueOf(str2)+d0);

	}

}
