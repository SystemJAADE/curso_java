package pe.edu.galaxy.training.java.jd0.matematicos.math;

public class AppMath {

	public static void main(String[] args) {
		
		System.out.println(Math.pow(2, 3));
		
		System.out.println(Math.sqrt(16));
		
		System.out.println(Math.abs(1));
		System.out.println(Math.abs(-1));
		
		System.out.println(Math.max(10,2));
		
		System.out.println(Math.PI);
		System.out.println(Math.E);
		
	}
}
