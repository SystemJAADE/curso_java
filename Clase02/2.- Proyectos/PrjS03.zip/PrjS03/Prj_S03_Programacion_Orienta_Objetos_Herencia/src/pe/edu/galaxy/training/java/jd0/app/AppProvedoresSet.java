package pe.edu.galaxy.training.java.jd0.app;

import java.util.HashSet;
import java.util.Set;

import pe.edu.galaxy.training.java.jd0.beans.Provedor;

public class AppProvedoresSet {

	public static void main(String[] args) {
		// Coleccion
		Set<Provedor> provedores = new HashSet<>();
		Provedor provedor=new Provedor(100, "Productos Amazonences", "2054987254");
		provedores.add(provedor);
		provedores.add(new Provedor(200, "Inversiones la Cruz", "1054987200"));
		provedores.add(provedor);

		provedores.forEach(System.out::println);
	}

}
