package pe.edu.galaxy.training.java.jd0.estfor;

public class AppFor {

	public static void main(String[] args) {

		for (int i = 0; i < 10; i++) {
			System.out.println(i);
		}

		System.out.println();

		int x = 1;
		for (; x < 5; x++) {
			System.out.println(x);
		}

		System.out.println();
		for (int i = 9; i >= 0; i--) {
			System.out.println(i);
		}
		System.out.println();
		for (int i = 0; i < 20; i += 4) {
			System.out.println(i);
		}

	}

}
