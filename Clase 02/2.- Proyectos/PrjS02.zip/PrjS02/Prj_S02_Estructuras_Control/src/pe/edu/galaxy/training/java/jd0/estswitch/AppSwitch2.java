package pe.edu.galaxy.training.java.jd0.estswitch;

public class AppSwitch2 {

	public static void main(String[] args) {
		
		/* Entero, char, String*/
		
		int key=13;
		
		switch (key) {
			case 1:{
				System.out.println("Enero");
				break;
			}
			case 2:{
				System.out.println("Febrero");
				break;
			}
			
			case 6:
			case 7:
			{
				System.out.println("Fin de semana");
				break;
			}
			
			default:
				System.out.println("No v�lido");
				break;
			}
	}

}
