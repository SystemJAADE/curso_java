package pe.edu.galaxy.training.java.jd0.fechas;

import java.text.SimpleDateFormat;

import java.time.LocalDate;

import java.util.Date;

public class AppFechas {

	public static void main(String[] args) {
		
		Date hoy= new Date();
		System.out.println(hoy);
		
		SimpleDateFormat sdf= new SimpleDateFormat("dd/mm/yyyy");
		System.out.println(sdf.format(hoy));
		
		
		sdf= new SimpleDateFormat("hh:mm:ss");
		System.out.println(sdf.format(hoy));
		
		sdf= new SimpleDateFormat("dd/mm/yyyy hh:mm");
		System.out.println(sdf.format(hoy));
		
		System.out.println(LocalDate.now());
		
		System.out.println(LocalDate.now().plusDays(5));
		System.out.println(LocalDate.now().plusYears(1));
		
		System.out.println(new java.sql.Date(123333333L));
		
	}
	
}
