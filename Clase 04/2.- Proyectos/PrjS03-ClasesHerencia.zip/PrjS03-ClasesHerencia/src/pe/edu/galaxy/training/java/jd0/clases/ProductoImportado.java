package pe.edu.galaxy.training.java.jd0.clases;

import java.util.Date;

public final class ProductoImportado extends Producto{

	private Date fechaImportacion;
	private Importador importador;

	public ProductoImportado() {
		super();
	}
	public Date getFechaImportacion() {
		return fechaImportacion;
	}
	public void setFechaImportacion(Date fechaImportacion) {
		this.fechaImportacion = fechaImportacion;
	}
	public Importador getImportador() {
		return importador;
	}
	public void setImportador(Importador importador) {
		this.importador = importador;
	}
	
	
}
